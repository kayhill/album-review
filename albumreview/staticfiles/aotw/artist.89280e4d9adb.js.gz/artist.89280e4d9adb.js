document.addEventListener('DOMContentLoaded', function() {
    
    var collapse = document.querySelectorAll('.collapsible');
     M.Collapsible.init(collapse);
    
});